@extends('layouts.app')

@section('nav')
    @include('partials.nav')
@endsection
