
<footer id="footer">
    <p>&copy; 2015<a href="{{ url('/') }}">Latter Africa</a>, inc. All rights reserved.</p>
</footer>
